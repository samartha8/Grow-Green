const express = require("express");
const fs = require("fs");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Load canned replies
const cannedReplies = JSON.parse(fs.readFileSync("cannedReplies.json", "utf8"));

// Affirmations list
const affirmations = [
  "You are stronger than you think ❤️",
  "Better days are coming 🌸",
  "I'm proud of you for sharing this with me 😊",
  "You matter and you are loved 💖",
  "It's okay to not be okay sometimes 🌈"
];

// Load existing journal logs or create new
let journalLog = [];
const journalFile = "journals.json";
if (fs.existsSync(journalFile)) {
  journalLog = JSON.parse(fs.readFileSync(journalFile, "utf8"));
}

// Root endpoint
app.get("/", (req, res) => {
  res.send("ChhoriBot backend is running locally, no AI API needed!");
});

// Chat endpoint
app.post("/chat", (req, res) => {
  const userMessage = req.body.message.toLowerCase();

  // Save message to journal
  journalLog.push({ message: userMessage, time: new Date().toISOString() });
  fs.writeFileSync(journalFile, JSON.stringify(journalLog, null, 2));

  // Exact canned reply
  if (cannedReplies[userMessage]) {
    return res.json({ reply: cannedReplies[userMessage] });
  }

  // Keyword-based detection
  if (userMessage.includes("period") || userMessage.includes("menstruation")) {
    if (userMessage.includes("pain") || userMessage.includes("cramps")) {
      return res.json({ reply: "Period cramps can be eased with heat pads, gentle exercise, and herbal teas. You're doing great!" });
    }
    if (userMessage.includes("how long") || userMessage.includes("last")) {
      return res.json({ reply: "Periods usually last between 3 to 7 days, but it can vary. Track your cycle to get a better idea!" });
    }
    if (userMessage.includes("heavy") || userMessage.includes("bleeding")) {
      return res.json({ reply: "Heavy bleeding can be serious. Please consult a healthcare professional if it concerns you. Stay safe!" });
    }
    return res.json({ reply: "Periods are a natural part of health. Let me know what you'd like help with!" });
  }

  if (userMessage.includes("sad") || userMessage.includes("depressed") || userMessage.includes("unhappy") || userMessage.includes("lonely") || userMessage.includes("alone")) {
    const randomAffirmation = affirmations[Math.floor(Math.random() * affirmations.length)];
    return res.json({ reply: `I'm really sorry you're feeling this way. ${randomAffirmation}` });
  }

  if (userMessage.includes("stress") || userMessage.includes("anxious") || userMessage.includes("anxiety")) {
    return res.json({ reply: "Stress and anxiety can be tough. Try deep breathing, a short walk, or venting to me here 😊" });
  }

  if (userMessage.includes("tired") || userMessage.includes("fatigue")) {
    return res.json({ reply: "Feeling tired is normal sometimes, especially during periods. Rest up and stay hydrated!" });
  }

  if (userMessage.includes("bye") || userMessage.includes("goodbye") || userMessage.includes("see you")) {
    return res.json({ reply: "Take care! Remember, I'm always here if you want to talk again ❤️" });
  }

  // Fallback
  return res.json({
    reply: "I'm here for you anytime. Could you please tell me more or ask me something related to health, periods, or how you're feeling? 😊"
  });
});

// Start server
app.listen(3000, () => {
  console.log("ChhoriBot backend running at http://localhost:3000");
});
